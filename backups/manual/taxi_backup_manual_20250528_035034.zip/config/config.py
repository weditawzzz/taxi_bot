# Временный config.py для совместимости
from core.config import Config

# Экспортируем все для совместимости
__all__ = ['Config']