BEGIN TRANSACTION;
CREATE TABLE archived_orders
                             (
                                 id
                                 INTEGER
                                 PRIMARY
                                 KEY,
                                 original_id
                                 INTEGER,
                                 order_data
                                 TEXT,
                                 reason
                                 TEXT,
                                 archived_at
                                 TIMESTAMP
                                 DEFAULT
                                 CURRENT_TIMESTAMP
                             );
COMMIT;
